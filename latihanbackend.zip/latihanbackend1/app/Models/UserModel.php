<?php

namespace App\Models;

use CodeIgniter\Model;
use Ramsey\Uuid\Uuid;

class UserModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'user';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'uuid',
        'name',
        'nohp',
        'email',

        'created_at',
        'updated_at',
        'deleted_at',
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function createUser($user_object) {
        $uuid4 = Uuid::uuid4();
        $generatedUUID = $uuid4;
        $this->save([
            'uuid' => $generatedUUID,
            'name' => $user_object['name'],
            'nohp' => $user_object['nohp'],
            'email' => $user_object['email']
        ]);
        return [
            'id' => $this->getInsertID(),
            'uuid' => $generatedUUID,
            'name' => $user_object['name'],
        ];
    }

    public function updateUser($user_uuid, $user_object) {
        $this->where('uuid', $user_uuid)->set([
            'name' => $user_object['name'],
            'nohp' => $user_object['nohp'],
            'email' => $user_object['email'],
        ])->update();
    }
}