<?php



namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ItemModel;
use App\Models\UserModel;
use Config\Validation;

class UserController extends BaseController
{
    private $validation;
    public function __construct() {
        $this->validation = \Config\Services::validation();
    }
    /**
     * Get : /user/list
     * @return string
     */
    public function user_list(){
        $userModel = new UserModel();
        $getUser = $userModel -> findAll();
        $word = 'hello world';
        return view('user_list', [
            'user_list' => $getUser,
            'word' => $word,
        ]);
    }

    /**
     * POST : /user/create/submit
     * @return \CodeIgniter\HTTP\RedirectResponse
     */
    public function user_create_submit(){
        $name = $this->request->getVar('name');
        $nohp = $this->request->getVar('nohp');
        $email = $this->request->getVar('email');

        $userModel = new UserModel();
        $InsertResult = $userModel->createUser([
            'name' => $name,
            'nohp' => $nohp,
            'email' => $email,
        ]);
        if (!empty($insertResult['id'])){
            return redirect()->to('/user/list')->with('success', 'success adding user');
        } else
            return redirect()->to('/user/list')->with('errors', 'failed when adding user');
    }



    /**
     * GET : /user/edit/$uuid
     * @param mixed $user_uuid
     * @return \CodeIgniter\HTTP\RedirectResponse|string
     */
    public function user_edit($user_uuid){
        $userModel = new UserModel();
        $data_user = $userModel->where('uuid', $user_uuid)->first();
        if(!empty($data_user)){
            return view('user_edit', [
                'data_user' => $data_user,
            ]);
        }else
            return redirect()->to('/user/list')->with('errors', 'user not found');
    }

    /**
     * POST : /user/edit/$uuid/submit
     * @return \CodeIgniter\HTTP\RedirectResponse
     */
    public function user_edit_submit($user_uuid){
        $userModel = new UserModel();
        $getUser = $userModel->where('uuid', $user_uuid)->first();
        if(!empty($getUser)){
            $userModel->where('uuid', $user_uuid)->set([
                'name' => $this->request->getVar('name'),
                'nohp' => $this->request->getVar('nohp'),
                'email' => $this->request->getVar('email'),
            ])->update();
            return redirect()->to('/user/list')->with('success', 'success updating user');
        } else return redirect()->to('/user/list')->with('error', 'error when updating user');
    }

    /**
     * GET : /user/delete/$uuid
     * @return \CodeIgniter\HTTP\RedirectResponse
     */
    public function user_delete($user_uuid){
        $userModel = new UserModel();
        $getUser = $userModel->where('uuid', $user_uuid)->first();
        if(!empty($getUser)){
            $userModel->where('uuid', $user_uuid)->delete();
            return redirect()->to('/user/list')->with('success', 'success deleting user');
        } else return redirect()->to('/user/list')->with('error', 'error when deleting user');
    }    
}