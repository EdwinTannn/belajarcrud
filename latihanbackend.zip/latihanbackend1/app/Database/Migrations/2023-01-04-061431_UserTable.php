<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UserTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => ['type' => 'INT','constraint' => 11,'auto_increment' => true,],
            'uuid' => ['type' => 'VARCHAR','constraint' => 64],
            'name' => ['type' => 'VARCHAR','constraint' => 255],
            'nohp' => ['type' => 'VARCHAR','constraint' => 13],
            'email' => ['type' => 'VARCHAR', 'constraint' => 30],

            # timestamps 
            'created_at' => ['type' => 'DATETIME', 'NULL' => TRUE],
            'updated_at' => ['type' => 'DATETIME', 'NULL' => TRUE],
            'deleted_at' => ['type' => 'DATETIME', 'NULL' => TRUE],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('user');
    }

    public function down()
    {
        $this->forge->dropTable('user');
    }
}
