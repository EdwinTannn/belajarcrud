<!DOCTYPE html>
<html lang="en">
<head>
    <title>User list</title>
</head>
<body>
    <form method="post" action="/user/edit/<?= esc($data_user['uuid']) ?>/submit" enctype="multipart/form-data">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="<?= esc($data_user['name']) ?>">
        <br>
        <label for="nohp">No HP</label>
        <input type="number" id="nohp" name="nohp" value="<?= esc($data_user['nohp']) ?>">
        <br>
        <label for="email">Email</label>
        <input type="text" id="email" name="email" value="<?= esc($data_user['email']) ?>">
        <br>
        <button type="submit">Update</button>
        <br>
    </form>
    <br>
</body>
</html>