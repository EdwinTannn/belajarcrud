<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container">
<form method="post" action="/user/create/submit" enctype="multipart/form-data">
        <label for="name">User Name</label>
        <input type="text" class="form-control" id="name" name="name">
        <br>
        <label for="nohp">No HP</label>
        <input type="number" class="form-control" id="nohp" name="nohp">
        <br>
        <label for="email">Email</label>
        <input type="text" class="form-control" id="email" name="email">
        <br> 
        <button type="submit">Submit</button>
        <br>
    </form>
</div>
    <br>
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th>No.</th>
                <th>Name</th>
                <th>No HP</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $index = 1; foreach($user_list as $data): ?>
                <tr>
                    <td><?= $index++; ?></td>
                    <td><?= esc($data['name']) ?></td>
                    <td><?= esc($data['nohp']) ?></td>
                    <td><?= esc($data['email']) ?></td>
                    <td>
                        <a href="/user/edit/<?= esc($data['uuid']) ?>">Edit</a>
                        <a href="/user/delete/<?= esc($data['uuid']) ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html>